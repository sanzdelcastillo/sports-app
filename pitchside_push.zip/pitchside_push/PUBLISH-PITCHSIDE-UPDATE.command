#!/bin/bash
cd "$(dirname "$0")"; HERE="$(pwd)"
stop() { echo ""; echo "$1"; read -n 1 -s -r -p "Press any key to close."; exit 1; }
echo ""; echo "=== Pitchside: publishing the update ==="; echo ""
command -v git >/dev/null 2>&1 || stop "Git is not installed. A window may offer to install developer tools: accept it, wait, then double-click this file again."
[ -f "$HERE/pitchside-update.bundle" ] || stop "I cannot find pitchside-update.bundle next to this file. Unzip the whole zip first."
REPO=""
for P in "$HOME/sports-app" "$HOME/Documents/sports-app" "$HOME/Desktop/sports-app" "$HOME/Documents/GitHub/sports-app" "$HOME/Downloads/sports-app"; do
  [ -z "$REPO" ] && [ -d "$P/.git" ] && REPO="$P"
done
if [ -z "$REPO" ]; then
  echo "No sports-app folder found, downloading the code..."
  git clone https://github.com/sanzdelcastillo/sports-app "$HOME/Documents/sports-app" || stop "The download failed. Send Claude a photo of this window."
  REPO="$HOME/Documents/sports-app"
fi
echo "Using the code folder: $REPO"; cd "$REPO"
git checkout main >/dev/null 2>&1
git pull --ff-only || stop "Could not get the latest code. Nothing was changed. Send Claude a photo of this window."
git fetch "$HERE/pitchside-update.bundle" main || stop "Could not read the update file. Nothing was changed."
git merge --ff-only FETCH_HEAD || stop "The update did not fit on top of the current code. Nothing was uploaded. Send Claude a photo of this window."
echo ""; echo "Uploading to GitHub..."
git push origin main || stop "The upload FAILED. Send Claude a photo of this window."
echo ""; echo "DONE. The live app updates in about a minute."
read -n 1 -s -r -p "Press any key to close."
